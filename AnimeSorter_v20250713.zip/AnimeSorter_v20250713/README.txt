# AnimeSorter - 실행 파일

## 사용 방법

1. **API 키 설정**
   - `config_template.yaml` 파일을 `config.yaml`로 복사
   - `config.yaml` 파일에서 `your_tmdb_api_key_here`를 실제 TMDB API 키로 교체

2. **실행**
   - `AnimeSorter.exe` 파일을 더블클릭하여 실행

## TMDB API 키 발급

1. https://www.themoviedb.org/ 에서 계정 생성
2. 설정 → API → API 키 요청
3. 개인 사용 목적으로 신청
4. 발급받은 API 키를 config.yaml에 입력

## 설정 파일 (config.yaml)

```yaml
tmdb:
  api_key: "여기에_실제_API_키_입력"
  language: "ko-KR"
  cache_enabled: true

# 기타 설정들...
```

## 문제 해결

- **실행 안됨**: Windows Defender나 백신 프로그램에서 차단될 수 있습니다
- **API 오류**: config.yaml의 API 키가 올바른지 확인하세요
- **파일 권한 오류**: 관리자 권한으로 실행해보세요

## 지원

문제가 있으면 GitHub 이슈로 문의하세요.
